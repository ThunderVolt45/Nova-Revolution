// Fill out your copyright notice in the Description page of Project Settings.

#include "GAS/NovaResourceAttributeSet.h"
#include "GameplayEffectExtension.h"

UNovaResourceAttributeSet::UNovaResourceAttributeSet()
{
	InitCurrentWatt(600.f);
	InitMaxWatt(2000.f);
	InitCurrentSP(40.f);
	InitMaxSP(100.f);
	InitMaxPopulation(20.f);
	InitMaxUnitWatt(6000.f);
	
	// AttributeSet 초기화 추가:
	InitWattLevel(1.0f); // 와트 생산 레벨 1단계로 시작
	InitSPLevel(1.0f);   // SP 생산 레벨 1단계로 시작
}

void UNovaResourceAttributeSet::PreAttributeChange(const FGameplayAttribute& Attribute, float& NewValue)
{
	Super::PreAttributeChange(Attribute, NewValue);

	// 최대값에 맞춰 클램핑 처리
	if (Attribute == GetCurrentWattAttribute())
	{
		NewValue = FMath::Clamp(NewValue, 0.0f, GetMaxWatt());
	}
	else if (Attribute == GetCurrentSPAttribute())
	{
		NewValue = FMath::Clamp(NewValue, 0.0f, GetMaxSP());
	}
	else if (Attribute == GetCurrentPopulationAttribute())
	{
		NewValue = FMath::Clamp(NewValue, 0.0f, GetMaxPopulation());
	}
	else if (Attribute == GetTotalUnitWattAttribute())
	{
		NewValue = FMath::Clamp(NewValue, 0.0f, GetMaxUnitWatt());
	}
	else if (Attribute == GetWattLevelAttribute())
	{
		NewValue = FMath::Max(NewValue, 1.0f); // 최소 레벨 1 유지
	}
	else if (Attribute == GetSPLevelAttribute())
	{
		NewValue = FMath::Max(NewValue, 1.0f); // 최소 레벨 1 유지
	}
}

void UNovaResourceAttributeSet::PostGameplayEffectExecute(const FGameplayEffectModCallbackData& Data)
{
	Super::PostGameplayEffectExecute(Data);

	// 자원 소모/재생 GE 적용 후 BaseValue를 직접 클램핑하여 유령 자원 누적 방지
	if (Data.EvaluatedData.Attribute == GetCurrentWattAttribute())
	{
		SetCurrentWatt(FMath::Clamp(GetCurrentWatt(), 0.0f, GetMaxWatt()));
	}
	else if (Data.EvaluatedData.Attribute == GetCurrentSPAttribute())
	{
		SetCurrentSP(FMath::Clamp(GetCurrentSP(), 0.0f, GetMaxSP()));
	}
}
